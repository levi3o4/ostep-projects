/* 
 * Course: 3207
 * Coder: Eugene Levitsky
 * Assignemnt: Lab 0; wcat
 * wcat is a variation on cat; 
 * it prints several documents to the screen, line by line.
 */

#include <stdio.h>
#include <stdlib.h>

int catOneFile (char* fileName);
int traverseText (FILE* file);

//Consists of a for loop that initiates the printing process for each individual file.
int main (int argc, char *argv[]) {
    
    for (int i = 1; i < argc; i++) {
        
        catOneFile(argv[i]);
    }
    
    return 0;
}

//Opens the file, sends a pointer to the file to the rest of the procedure, and closes the file.
int catOneFile (char* fileName) {

    FILE *file = fopen(fileName, "r"); 
    
    if (file == NULL) {
        printf("cannot open file\n");
        exit(1); 
    }
    
    traverseText(file);
    
    fclose(file);
}

//Scrapes a line off the file, one at a time, until there are no more lines.
//Prints each line to screen.
int traverseText (FILE* text) {
    
    char* line = NULL;
    size_t length = 0;
    
    while (getline(&line, &length, text) != -1) {
        printf("%s", line);
    }
    
    puts("");

    free(line);
}