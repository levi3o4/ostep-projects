/* 
 * Course: 3207
 * Coder: Eugene Levitsky
 * Assignemnt: Lab 0; wgrep
 * wgrep is a variation on grep; 
 * it searches several documents for a given term, line by line. 
 * Any line containing that term is printed to the screen.
 */

#include <stdio.h>
#include <stdlib.h>

int getLength (char* string);
int grepOneFile (char* searchTerm, size_t searchTermLength, char* fileName);
int traverseText (char* searchTerm, size_t searchTermLength, FILE* file);
int search (char* searchTerm, size_t searchTermLength, char* line);
int compare (char* searchTerm, char* line, size_t offset);

//Consists of a for loop that initiates the searching process for each individual file.
//If there are no files, user is prompted to enter the text to be searched via stdin.
int main (int argc, char *argv[]) {
    
    if (argc == 1) {
        
        puts("wgrep: searchterm [file ...]");
        exit(1);
    } 
       
    size_t searchTermLength = getLength(argv[1]);
    
    if (argc == 2) {
        
        puts("Please enter some text to search through.");
        puts("When finished, please enter Ctrl+D.");
        traverseText(argv[1], searchTermLength, stdin);
        
    } else {
        
        for (int i = 2; i < argc; i++) {
            
            grepOneFile(argv[1], searchTermLength, argv[i]);
        }
    }
    
    return 0;
}

//Given a string that ends with '\0,' returns the length of the string, omitting '\0'
int getLength (char* string) {
    
    size_t length = 0;
    
    for (; *(string + length) != '\0'; length++) {
        ;
    }
    
    return length;
}

//Opens the file, sends a pointer to the file to the rest of the procedure, and closes the file.
int grepOneFile (char* searchTerm, size_t searchTermLength, char* fileName) {

    FILE *file = fopen(fileName, "r"); 
    
    if (file == NULL) {
        printf("wgrep: cannot open file\n");
        exit(1); 
    }
    
    traverseText(searchTerm, searchTermLength, file);
    
    fclose(file);
}

//Scrapes a line off the file, one at a time, until there are no more lines.
//Sends the line and the search term to search(). If search term is found, prints the line.
int traverseText (char* searchTerm, size_t searchTermLength, FILE* text) {
    
    char* line = NULL;
    size_t length = 0;
    
    while (getline(&line, &length, text) != -1) {
        
        if (search(searchTerm, searchTermLength, line)) {
            printf("%s", line);
        }
    }
    
    puts("");
    
    free(line);
}

//Traverses the line for potential positions of search term.
int search (char* searchTerm, size_t searchTermLength, char* line) {
    
    size_t lineLength = getLength(line);
    
    for (size_t offset = 0; searchTermLength + offset <= lineLength; offset++) {
        
        if (compare(searchTerm, line, offset)) {
            return 1;
        }
    }
    
    return 0;
}

//Compares a string to a substring.
int compare (char* searchTerm, char* line, size_t offset) {
    
    for (int i = 0; *(searchTerm + i) != '\0'; i++) {
       
        if (*(searchTerm + i) != *(line + offset + i)) {
            return 0;
        }
    }
    
    return 1;
}