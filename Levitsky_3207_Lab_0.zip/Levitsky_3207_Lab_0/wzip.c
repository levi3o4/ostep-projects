/* 
 * Course: 3207
 * Coder: Eugene Levitsky
 * Assignemnt: Lab 0; wzip
 * wzip is a variation on zip; 
 * it compresses several files into one document.
 */

#include <stdio.h>
#include <stdlib.h>

int zipOneFile (char* fileName);
int scanText (FILE* text);
int printEntry (int repetitions, char character);

//Consists of a for loop that initiates the zipping process for each individual file.
int main (int argc, char *argv[]) {
    
    if (argc == 1) {
        
        puts("wzip: file1 [file2 ...]");
        exit(1);
        
    }
    
    for (int i = 1; i < argc; i++) {
        
        zipOneFile(argv[i]);
    }
    
    return 0;
}

//Opens the file, sends a pointer to the file to the rest of the procedure, and closes the file.
int zipOneFile (char* fileName) {

    FILE *file = fopen(fileName, "r"); 
    
    if (file == NULL) {
        printf("wzip: cannot open file\n");
        exit(1); 
    }
    
    scanText(file);
    
    fclose(file);
}

//Scrapes a character off the file, one at a time, until there are no more characters.
//Counts the number of repetitions, then sends the rep number and the character to be printed.
int scanText (FILE* text) {

    char oldChar;
    
    if ((oldChar = (char) fgetc(text)) == EOF) {
        return 0;
    }
    
    char newChar;
    int counter = 1;

    while ((newChar = (char) fgetc(text)) != EOF) {

        if(newChar == oldChar) {
            counter++;
            
        } else {
            printEntry(counter, oldChar);
            oldChar = newChar;
            counter = 1; 
        }
    }

    printEntry(counter, oldChar);
    printEntry(2, '\n');
}

//Using fwrite(), prints the number of times a character is repeated,
//along with the character, to the screen.
int printEntry (int repetitions, char character) {
    
    fwrite(&repetitions, 4, 1, stdout);
    fwrite(&character, 1, 1, stdout);

    return 0;
}