/* 
 * Course: 3207
 * Coder: Eugene Levitsky
 * Assignemnt: Lab 0; wunzip
 * wunzip is a variation on unzip; 
 * it decompresses several compressed documents into one file.
 */
 
#include <stdio.h>
#include <stdlib.h>

int unzipOneFile (char* fileName);
int scanText (FILE* file);
int printContents (char repetitions, char character);

//Consists of a for loop that initiates the zipping process for each individual file.
int main (int argc, char *argv[]) {
    
    if (argc == 1) {
        
        puts("wunzip: file1 [file2 ...]");
        exit(1);
        
    }
    
    for (int i = 1; i < argc; i++) {
        
        unzipOneFile(argv[i]);
    }
    
    return 0;
}

//Opens the file, sends a pointer to the file to the rest of the procedure, and closes the file.
int unzipOneFile (char* fileName) {

    FILE *file = fopen(fileName, "r"); 
    
    if (file == NULL) {
        printf("wunzip: cannot open file\n");
        exit(1); 
    }
    
    scanText(file);
    
    fclose(file);
}

//Using fread(), scrapes two characters off the file at a time, until there are no more characters.
//Sends these characters (the number of reps and the character being repeated)
//to be decmpressed and printed.
int scanText (FILE* text) {

    int repetitions;
    char character;
    
    while ((fread(&repetitions, 4, 1, text)) == 1) {
        
        if ((fread(&character, 1, 1, text)) != 1) {
                exit(2);
        }
        
        printContents(repetitions, character);
    }
    
    //puts("");
}

//Prints a character to the screen a given number of times.
int printContents (char repetitions, char character) {
    
    for (int i = 0; i < repetitions; i++) {
        printf("%c", character);
    }
    
    return 0;
}