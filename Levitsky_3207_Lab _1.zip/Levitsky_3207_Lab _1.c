
/* 
 * Course: 3207
 * Coder: Eugene Levitsky
 * Assignemnt: Lab 1; Discrete Event Simulator
 * Simulates process travelling between CPU, two disks, and a network. 
 */

#include <stdio.h>
#include <stdlib.h>
#define SETTINGS_NUM 15 //Total number of settings

#define CPU 0   //indices of a component array
#define DISK_1 1
#define DISK_2 2
#define NETWORK 3
#define EVENT_QUEUE 4

//labels associated with each setting in the settings document;
//used to validate entries.
char* settingLabels[SETTINGS_NUM] = {"SEED", "INIT_TIME", "FIN_TIME", "ARRIVE_MIN", "ARRIVE_MAX", 
                      "QUIT_PROB", "CPU_MIN", "CPU_MAX", "DISK1_MIN", "DISK1_MAX", 
                      "DISK2_MIN", "DISK2_MAX", "NETWORK_MIN", "NETWORK_MAX", "NETWORK_PROB"};

//indices for the settings array
typedef enum SETTING_INDEX {
    SEED, 
    INIT_TIME, 
    FIN_TIME, 
    ARRIVE_MIN, 
    ARRIVE_MAX, 
    QUIT_PROB, 
    CPU_MIN, 
    CPU_MAX, 
    DISK1_MIN, 
    DISK1_MAX, 
    DISK2_MIN, 
    DISK2_MAX, 
    NETWORK_MIN, 
    NETWORK_MAX, 
    NETWORK_PROB
} SettingIndex;

int settings[SETTINGS_NUM]; //settings array;
                            //stores all the settings after they are read in from settings document

//reppresents a single process, or job.
//implemented as a node for a linked list.
typedef struct LINK {
    int num;
    int componentArrivalTime;
    struct LINK* next;
} Process;

//represents a single component of the system;
//includes the device, as well as critical elements 
//of its associated queue;
//the latter is implemented as a linked list.
typedef struct QUEUE {
    Process* device;
    Process* head;
    Process* tail;
    int length;
} Component;

Component component[4];     //array of components

//the different types of events
typedef enum EVENT_TYPE {
    ARRIVAL, 
    CPU_FINISH, 
    DISK1_FINISH, 
    DISK2_FINISH, 
    NETWORK_FINISH, 
    SIMULATION_END
} EventType;

//a single event
typedef struct EVENT {
    int eventTime;
    EventType type;
    int jobNum;
} Event;

FILE* logFile;  //pointer to the log file, updated regularly via multiple functions.

//the priority queue holding all the events
typedef struct PRIORITY_QUEUE {
    Event** array;
    int tailIndex;
    int arraySize;
} EventQueue;

EventQueue eventQueue;  //the specific instance of the 
                        //above-mentioned priority queue

int newJobNum = 1;      //the number that will be assigned to the next job
int currentTime = 0;    //current logical time
int previousTime = 0;   //most recent non-current logical time


int weightedTotalSize[5] = {0, 0, 0, 0, 0}; //various per-component tallies
int maxSize[5] = {0, 0, 0, 0, 0};           // for statistical analysis

int utilization[4] = {0, 0, 0, 0};

int totalResponseTime[4] = {0, 0, 0, 0};
int maxResponseTime[4] = {0, 0, 0, 0};

int jobsProcessed[4] = {0, 0, 0, 0};

int getSettings(char* settingsFileName);
int readIn (FILE* file);
int validSetting (FILE* file, int index);
int compare (char* label, int index);
int setSetting (FILE* file, int index);
int initializeSystems ();
int initializeComponent (int index);
int intializeEventQueue ();
int runSimulation ();
int enlargeEventQueue ();
int eventQueueInsert (int eventTimeParam, EventType typeParam, int jobNumParam);
int swapDecider (int parentIndex, int childIndex);
int swap (int parentIndex, int childIndex);
Event* eventQueuePull ();
int twoChildDecider (int parentIndex);
int systemArrivalHandler (int jobNum);
int createNewProcessArrivalEvent ();
int moveTo (int compIndex, Process* process);
int loadProcess (int compIndex, Process* process);
int createFinishingEvent (int compIndex, Process* process);
int componentFinishingEventHandler (EventType type);
int eventTypeToComponentConverter (EventType type);
int transferProcess (int source, int destination);
int processExit ();
int mostAvailableDisk ();
int cpuFinishingHandler ();
int getNewEventTime(int compIndex);
EventType getEventFinishingType(int compIndex);
int enqueue (int compIndex, Process* process);
int dequeue (int compIndex);
int updateStats ();
int writeStats (FILE* statistcsFile);
int createStatisticsFile ();
int writeToLogFileEvent (Event* event);
int writeToLogFileProcess (Process* process, int compIndex);
int writeSettingsToLogFile();

//intiates settings read-in, system initialization, random seeding, and a single run of the simulation.
int main(int argc, char* argv[]) {
    
    getSettings(argv[1]);
    
    initializeSystems();
    
    SettingIndex seed = settings[SEED];
    srand(seed);
    
    runSimulation();
    
    exit(0);
}

//Receives a filename, opens the file, passes the file pointer to readIn, and closes the file.
int getSettings(char* settingsFileName) {
    
    FILE *file = fopen(settingsFileName, "r"); 
    
    if (file == NULL) {
        printf("cannot open file\n");
        exit(1); 
    }
    
    readIn(file);
    
    fclose(file);
    
    return 0;
}

//For each of the settings, validates that the setting label and records the setting.
int readIn (FILE *file) {
    
    for (int i = 0; i < SETTINGS_NUM; i++) {
        
        if (validSetting(file, i)) {
            setSetting(file, i);
        
        } else {
            puts("File format compatibility issue.");
            exit(2);
        }
    }
    
    return 0;
}

//setting validator
//reads a single setting label, passes to a comparison function, and retuns the result
int validSetting (FILE *file, int index) {
    
    char label[20];
    
    fscanf(file, "%s", label);
    
    return compare(label, index);
}

//compares two strings; returns 1 if they match, 0 if the do not.
int compare (char* label, int index) {
    
    int offset = 0;
    char fileLabelChar;
    char arrayLabelChar;
    
    for (; (fileLabelChar = *(label + offset)) != '\0' && 
            (arrayLabelChar = *(*(settingLabels + index) + offset)) != '\0'; offset++) {
    
        if(fileLabelChar != arrayLabelChar) {
            return 0;
        }
    }
    
    if ((fileLabelChar = *(label + offset)) != '\0' || 
            (arrayLabelChar = *(*(settingLabels + index) + offset)) != '\0') {
        return 0;
    }
    
    return 1;
}

//reads a setting off a file, passes it to the appropriate member of the settings array.
int setSetting (FILE *file, int index) {
    
    int value;
    
    fscanf(file, "%d", &value);
    
    settings[index] = value;
    
    return 0;
}

//initiates the initialization of the four devices (and associated queues), 
//as well as the event priority queue.
int initializeSystems () {
    
    for (int i = CPU; i < NETWORK; i++) {
        initializeComponent(i);
    }
    
    intializeEventQueue();
    
    return 0;
}

//Given the index of a single member of the component array, initializes its associated device and queue.
int initializeComponent (int index) {
    
    component[index].device = NULL;
    component[index].head = NULL;
    component[index].tail = NULL;
    component[index].length = 0;
    
    return 0;
}

//initializes the event priority queue, including its underlying array, first event, and last (sentinel) event.
int intializeEventQueue () {
    
    eventQueue.arraySize = 2000;
    eventQueue.array = (Event**) malloc(eventQueue.arraySize * sizeof(Event*));
    eventQueue.tailIndex = 0;
    
    EventType event = ARRIVAL;
    eventQueueInsert(0, event, newJobNum++);
    
    event = SIMULATION_END;
    SettingIndex finTime = FIN_TIME;
    eventQueueInsert(settings[finTime], event, -1);
    
    return 0;
}

//runs a single simulation.
//pulls a single event off of the event priority queue, updates the current time,
//and responds to the event's type.
//If event type is SIMULATION END, the while loop (and simulation) terminate.
int runSimulation () {
    
    logFile = fopen("log_file.txt", "w");

    writeSettingsToLogFile();

    Event* current = eventQueuePull();

    currentTime = current->eventTime;
 
    writeToLogFileEvent(current);

    while (current->type != SIMULATION_END) {

        if (current->type == ARRIVAL) {
            systemArrivalHandler(current->jobNum);

        } else {
            componentFinishingEventHandler(current->type);
        }

        free(current);
        current = eventQueuePull();
        writeToLogFileEvent(current);
        
        previousTime = currentTime;
        currentTime = current->eventTime;
        
        updateStats();
        
    }
    
    createStatisticsFile();
    
    return 0;
}

//updates some of the statistics every time the simulation's while loop 
//reaches the end of a single iteration
int updateStats () {

    for (int i = CPU; i <= NETWORK; i++) {
    
        weightedTotalSize[i] += (component[i].length * (currentTime - previousTime));
        
        if (component[i].length > maxSize[i]) {
            maxSize[i] = component[i].length;
        }    
        
        if (component[i].device != NULL) {
            utilization[i] += (currentTime - previousTime);
        }
        
    }
    
    weightedTotalSize[EVENT_QUEUE] += (eventQueue.tailIndex * (currentTime - previousTime));
        
        if (eventQueue.tailIndex > maxSize[EVENT_QUEUE]) {
            maxSize[EVENT_QUEUE] = eventQueue.tailIndex;
        }  
    
    return 0;   
}

//writes the statistics file
int writeStats (FILE* file) {
    
    char* componentName[5] = {"CPU", "DISK 1", "DISK 2", "NETWORK", "EVENT QUEUE"};
    
    for (int i = CPU; i <= EVENT_QUEUE; i++) {

        fprintf(file, "Device:                  %s\n", componentName[i]);
        fprintf(file, "Average Size:            %.2f\n", ((double) weightedTotalSize[i] / currentTime));
        fprintf(file, "Max Size:                %d\n", maxSize[i]);
        
        if (i != EVENT_QUEUE) {
            fprintf(file, "Utilization:             %d\n", utilization[i]);
            fprintf(file, "Average Response Time:   %.2f\n", ((double) totalResponseTime[i] / jobsProcessed[i]));
            fprintf(file, "Max Response Time:       %d\n", maxResponseTime[i]);
            fprintf(file, "Throughput:              %.4f\n", ((double) jobsProcessed[i] / currentTime));
        }
        
        fputs("\n", file);
    }
}

//creates statistics file
int createStatisticsFile () {
    
    FILE* statisticsFile = fopen("statistics_file.txt", "w");
    
    writeStats(statisticsFile);
    
    fclose(statisticsFile);
    
    return 0;
}

//writes the configuration settings to the log file
int writeSettingsToLogFile() {

fprintf(logFile, "%s", "Configurations:\n");

    for (int i = 0; i < SETTINGS_NUM; i++) {
        fprintf(logFile, "%s\t%d\n", settingLabels[i], settings[i]);
    }
    fputs("\n", logFile);
}

//Records an event in the log file.
//This version of the function is for events
//that are part of the event queue system.
int writeToLogFileEvent (Event* event) {

    char* string;
    
    if (event->type == SIMULATION_END) {
        
        fprintf(logFile, "At time %d, simulation finished", event->eventTime);
        return 0;
    }
    
    switch(event->type) {
        
        case ARRIVAL:
            string = "arrives." ;
            break;
            
        case CPU_FINISH:
            string = "finishes in the CPU.";
            break;
	    
	    case DISK1_FINISH:
            string = "finishes in Disk 1.";
            break;
	
	    case DISK2_FINISH:
            string = "finishes in Disk 2.";
            break;
	
	    case NETWORK_FINISH:
            string = "finishes in the Network.";
            break;
    }
    
    fprintf(logFile, "At time %d, Job %d %s\n", event->eventTime, event->jobNum, string);
}

//Records an event in the log file.
//This version of the function is for device arrivals,
//and takes a process in as a paramater,
//as device arrivals are not part of the event queue system.
int writeToLogFileProcess (Process* process, int compIndex) {
    
    char* string;
        
    switch(compIndex) {
        
    case CPU:
        string = "the CPU.";
        break;
    
    case DISK_1:
        string = "Disk 1.";
        break;

    case DISK_2:
        string = "Disk 2.";
        break;
	
    case NETWORK:
        string = "the Network.";
        break;
    }
    
    fprintf(logFile, "At time %d, Job %d enters %s\n", currentTime, process->num, string);
}

//implements the arrival of a new process into the system.
//creates a process based on an incoming event (specifically, its job number),
//moves the process to the CPU,
//and initiates the creation of a new process event.
int systemArrivalHandler (int jobNum) {

    Process *process = (Process*) malloc(sizeof(Process));
    process->num = jobNum;
    process->componentArrivalTime = currentTime;
    process->next = NULL;

    moveTo(CPU, process);

    createNewProcessArrivalEvent();
    
    return 0;
}

//moves a process to a given component.
//if component is free, the process is loaded into the component device.
//otherwise, it is added to the component queue.
int moveTo (int compIndex, Process *process) {

    if (component[compIndex].device == NULL) {

        loadProcess(compIndex, process);

    } else {
        enqueue(compIndex, process);
    }
    
    return 0;
}

//assigns process pointer to device
//and initiates the creation of the process' finishing-at-this-device event
int loadProcess (int compIndex, Process* process) {
    
    writeToLogFileProcess(process, compIndex);
    
    process->next = NULL;

    component[compIndex].device = process;

    if (component[compIndex].device != NULL) {
        createFinishingEvent(compIndex, process);
    }

    return 0;
}

//gathers the information necessary for a new finishing event and feeds it to the event event creator.
int createFinishingEvent (int compIndex, Process* process) {
    
    int newEventTime = getNewEventTime(compIndex);

    EventType newEventType = getEventFinishingType(compIndex);

    eventQueueInsert(newEventTime, newEventType, process->num);

    return 0;
}

//returns an appropriate finishing time for a given component.
int getNewEventTime(int compIndex) {

    SettingIndex siMin;
    SettingIndex siMax;
    
    switch(compIndex) {

        case CPU:
            siMin = CPU_MIN;
            siMax = CPU_MAX;
            break;
	    
	    case DISK_1:
            siMin = DISK1_MIN;
            siMax = DISK1_MAX;
            break;
	
	    case DISK_2:
            siMin = DISK2_MIN;
            siMax = DISK2_MAX;
            break;
	
	    case NETWORK:
            siMin = NETWORK_MIN;
            siMax = NETWORK_MAX;
            break;
    }
    
    int min = settings[siMin];
    int max = settings[siMax];
    
    return currentTime + min + (rand() % (max - min));
}

//returns an appropriate finishing eventType for a given component.
EventType getEventFinishingType (int compIndex) {
    
    EventType type;
    
    switch(compIndex) {

        case CPU:
            type = CPU_FINISH;
            break;
	    
	    case DISK_1:
            type = DISK1_FINISH;
            break;
	
	    case DISK_2:
            type = DISK2_FINISH;
            break;
	
	    case NETWORK:
            type = NETWORK_FINISH;
            break;
    }
    
    return type;
}

//Should probably split into two functions at some point
//accepts the fields of an event struct, creates a new event,
//and inserts it into the event priority queue.
//if priority queue is out of space, it is enlarged.
int eventQueueInsert (int eventTimeParam, EventType typeParam, int jobNumParam) {

    Event* event = (Event*) malloc(sizeof(Event));
    event->eventTime = eventTimeParam;
    event->type = typeParam;
    event->jobNum = jobNumParam;
    
    eventQueue.array[eventQueue.tailIndex] = event;
    
    int currentIndex = eventQueue.tailIndex;
    int indexCopy = currentIndex;
    
    int done = 0;
    
    while (!done && currentIndex > 0) {
        
        done = swapDecider((currentIndex - 1) / 2, currentIndex);
        
        if (!done) {
            
            indexCopy = (currentIndex - 1) / 2;

        } else {
            
            indexCopy = currentIndex;

        }
        
        currentIndex = (currentIndex - 1) / 2;
    }
    
    eventQueue.tailIndex++;
    
    if (eventQueue.tailIndex >= eventQueue.arraySize) {
        
        enlargeEventQueue(indexCopy);
    }
    
    return 0;
}

//given the array indices of a parent-child pair in a priority queue, determines if they need to be swapped.
//if so, passes them to swap() and returns 0; otherwise, returns 1.
int swapDecider (int parentIndex, int childIndex) {
    
    if (eventQueue.array[parentIndex]->eventTime > eventQueue.array[childIndex]->eventTime) {
        swap(parentIndex, childIndex);
        return 0;
    
    } else {
        return 1;
    }
}

//given two indices of a priority queue's underlying array, swaps the elements of the array.
int swap(int parentIndex, int childIndex) {
 
    Event* temp = eventQueue.array[parentIndex];
    eventQueue.array[parentIndex] = eventQueue.array[childIndex];
    eventQueue.array[childIndex] = temp; 
    
    return 0;
}

//given a dynamically allocated array, triples its size.
int enlargeEventQueue () {//REMOVE PARAMETER LATER
    
    eventQueue.arraySize *= 3;
    eventQueue.array = (Event**) realloc(eventQueue.array, eventQueue.arraySize);
    
    return 0;
}

//enqueues a given process in a given component's queue.
int enqueue (int compIndex, Process* process) {
    
    if (component[compIndex].head == NULL) {
        
        component[compIndex].head = process;
        component[compIndex].tail = process;

    } else {
        component[compIndex].tail->next = process;
        component[compIndex].tail = process;
    }
    
    component[compIndex].length++;

    return 0;
}

//creates a new process arrival event; to be used when a process arrives in the system.
int createNewProcessArrivalEvent () {
    
    int min = settings[ARRIVE_MIN];
    int max = settings[ARRIVE_MAX];
    
    int newEventTime = currentTime + min + (rand() % (max - min));
    EventType arrival = ARRIVAL;
    
    eventQueueInsert(newEventTime, arrival, newJobNum++);

    return 0;
}

//responds to an incoming event in which a process finishes its time at a device.
int componentFinishingEventHandler (EventType type) {
    
    int compIndex = eventTypeToComponentConverter(type);
    
    if (compIndex == CPU) {
        
        cpuFinishingHandler();
        
    } else {
        transferProcess(compIndex, CPU);
    }
    
    return 0;
}

//returns an appropriate component index for a given event type.
int eventTypeToComponentConverter (EventType type) {
    
    int compIndex;
    
    switch(type) {

        case CPU_FINISH:
            compIndex = CPU;
            break;
	    
	    case DISK1_FINISH:
            compIndex = DISK_1;
            break;
	
	    case DISK2_FINISH:
            compIndex = DISK_2;
            break;
            
        case NETWORK_FINISH:
            compIndex = NETWORK;
            break;
    }
    
    return compIndex;
}

//responds to a CPU_FINISH event.
//Using given probabilities, simulates a decision process for a process' next step after CPU:
//Exiting the system, going to the network, or going to one of two discs.
int cpuFinishingHandler () {

    SettingIndex quitProb = QUIT_PROB;
    SettingIndex networkProb = NETWORK_PROB;

    if (rand() % 100 < settings[quitProb]) {

        processExit();

    } else if (rand() % 100 < settings[networkProb]) {

        transferProcess(CPU, NETWORK);

    } else {

        transferProcess(CPU, mostAvailableDisk());
    }
    
    return 0;
}

//Actions implemented when process leaves CPU
//Associated memory is freed.
int processExit () {

    int responseTime = (currentTime - component[CPU].device->componentArrivalTime);
    totalResponseTime[CPU] += responseTime;
    
    if (responseTime > maxResponseTime[CPU]) {
        maxResponseTime[CPU] = responseTime;
    }
    
    jobsProcessed[CPU]++;
    
    fprintf(logFile, "At time %d, Job %d exits the system.\n", currentTime, component[CPU].device->num);
    
    free(component[CPU].device);
    
    component[CPU].device = NULL;
    
    if (component[CPU].head != NULL) {
        loadProcess(CPU, component[CPU].head);
        dequeue(CPU);
    }
    return 0;
}

//removes a process from the head of the queue.
int dequeue (int compIndex) {
    
    component[compIndex].head = component[compIndex].head->next;
    
    if (component[compIndex].head == NULL) {
        component[compIndex].tail = NULL;
    }
    
    component[compIndex].length--;
    
    if (component[compIndex].length < 0) {
        component[compIndex].length = 0;
    }
    
    return 0;
}

//moves a process from one component to another, removing it from current device and
//placing  it in either the destination component's device, or in its queue.
int transferProcess (int source, int destination) {

    int responseTime = (currentTime - component[source].device->componentArrivalTime);
    totalResponseTime[source] += responseTime;
    
    if (responseTime > maxResponseTime[source]) {
        maxResponseTime[source] = responseTime;
    }
    
    jobsProcessed[source]++;
    
    component[source].device->componentArrivalTime = currentTime;
    moveTo(destination, component[source].device);

    component[source].device = NULL;
    
    if (component[source].head != NULL) {

        loadProcess(source, component[source].head);

        dequeue(source);
    }
    return 0;
}

//returns an the next scheduled Event;
//implemented as a priority queue.
Event* eventQueuePull () {

    Event* retval = eventQueue.array[0];
    
    eventQueue.array[0] = eventQueue.array[--eventQueue.tailIndex];

    int currentIndex = 0;
    
    int result = 1;
    
    while (result) {
        
        if ((currentIndex * 2) + 2 < eventQueue.tailIndex) {
            
            result = twoChildDecider(currentIndex);
            currentIndex = (currentIndex * 2) + result;
        
        } else if ((currentIndex * 2) + 1 < eventQueue.tailIndex) {
            
            result = 1 - swapDecider(currentIndex, (currentIndex * 2) + 1);
            currentIndex = (currentIndex * 2) + 1;
            
        } else {
            
            result = 0;
        }
        
    }
    
    return retval;
}

//after an element is pulled off the heap, aids in reheapification
//by determining if a parent node needs to swap with either of its children.
int twoChildDecider (int parentIndex) {
    
    int child = 1;
    
    int childIndexPre = (parentIndex * 2);

    if (eventQueue.array[childIndexPre + 1]->eventTime > eventQueue.array[childIndexPre + 2]->eventTime) {
        
        child++;
    }
    
    if (!swapDecider(parentIndex, (childIndexPre + child))) {
        return child;
    
    } else {
        return 0;
    }
}

//returns the index component index associated with the disk with the shortest queue,
//or selects a disk t random if both queues are of equal length.
int mostAvailableDisk () {
        
    if (component[DISK_1].length < component[DISK_2].length) {
        return DISK_1;
    } 
    
    if (component[DISK_1].length > component[DISK_2].length) {
        return DISK_2;
    } 
    
    int coin = rand() % 2;
            
    if (coin) {
        return DISK_1;
    } 
    
    return DISK_2;
}